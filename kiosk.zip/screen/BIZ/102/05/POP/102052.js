﻿function btn_close_on_click(objInst)
{
		this.screen.unloadpopup();
}