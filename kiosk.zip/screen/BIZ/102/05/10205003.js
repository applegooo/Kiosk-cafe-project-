﻿function test_on_click(objInst)
{
	this.screen.loadportletpopup("결제방법선택", "/BIZ/102/05/POP/10205101", "메뉴선택",true,XFD_BORDER_NONE, 90, 252,0,0, false,true,false);
}