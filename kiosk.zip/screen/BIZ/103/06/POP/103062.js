﻿function screen_on_load()
{
	
}    

function btn_ok_on_click(objInst)
{
	this.screen.unloadpopup();
}