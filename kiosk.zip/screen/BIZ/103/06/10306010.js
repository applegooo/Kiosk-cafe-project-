﻿function screen_on_load()
{
	
}    

function btn_on_click(objInst)
{
	this.screen.loadportletpopup("결제방법선택", "/BIZ/103/06/POP/103061", "호차",true,XFD_BORDER_NONE, 90, 252,0,0, false,true,false);
}