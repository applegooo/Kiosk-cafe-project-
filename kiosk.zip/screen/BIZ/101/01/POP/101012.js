﻿function btn_clo_on_mouseup(objInst)
{
	this.screen.unloadpopup();
}

function btn_next_on_mouseup(objInst)
{
	this.screen.unloadpopup();
}