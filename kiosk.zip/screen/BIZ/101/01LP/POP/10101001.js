﻿function btn_ok_on_mouseup(objInst)
{
	
}

function btn_clo_on_mouseup(objInst)
{
	this.screen.unloadpopup();
}